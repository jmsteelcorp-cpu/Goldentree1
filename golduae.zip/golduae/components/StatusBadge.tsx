const STYLES: Record<string, string> = {
  DRAFT: 'bg-ink/10 text-ink/70',
  AWAITING_PAYMENT: 'bg-brass/20 text-brass-dark',
  SUBMITTED: 'bg-brass/20 text-brass-dark',
  DOCS_UNDER_VERIFICATION: 'bg-blue-100 text-blue-700',
  DOCS_REJECTED: 'bg-red-100 text-red-700',
  IN_PROGRESS: 'bg-emerald/15 text-emerald',
  COMPLETED: 'bg-emerald text-white',
  CANCELLED: 'bg-ink/10 text-ink/50',
  PENDING_UPLOAD: 'bg-ink/10 text-ink/60',
  UNDER_VERIFICATION: 'bg-blue-100 text-blue-700',
  APPROVED: 'bg-emerald/15 text-emerald',
  REJECTED: 'bg-red-100 text-red-700',
  PENDING: 'bg-ink/10 text-ink/60',
  NOT_STARTED: 'bg-ink/10 text-ink/60',
  PRINTING: 'bg-brass/20 text-brass-dark',
  COURIER: 'bg-blue-100 text-blue-700',
  DELIVERED: 'bg-emerald text-white'
};

const LABELS: Record<string, string> = {
  DRAFT: 'Draft',
  AWAITING_PAYMENT: 'Awaiting payment',
  SUBMITTED: 'Submitted — upload documents',
  DOCS_UNDER_VERIFICATION: 'Documents under verification',
  DOCS_REJECTED: 'Documents need re-upload',
  IN_PROGRESS: 'In progress',
  COMPLETED: 'Completed',
  CANCELLED: 'Cancelled',
  PENDING_UPLOAD: 'Not uploaded',
  UNDER_VERIFICATION: 'Under verification',
  APPROVED: 'Approved',
  REJECTED: 'Rejected',
  PENDING: 'Pending',
  NOT_STARTED: 'Not started',
  PRINTING: 'Printing',
  COURIER: 'Out for courier',
  DELIVERED: 'Delivered'
};

export default function StatusBadge({ status }: { status: string }) {
  return (
    <span className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-medium ${STYLES[status] || 'bg-ink/10 text-ink/60'}`}>
      {LABELS[status] || status}
    </span>
  );
}
