'use client';

import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

const LOGIN_PATH: Record<string, string> = {
  USER: '/user/login',
  AGENT: '/agent/login',
  ADMIN: '/admin/login'
};

export default function AuthGate({ role, children }: { role: 'USER' | 'AGENT' | 'ADMIN'; children: React.ReactNode }) {
  const { data: session, status } = useSession();
  const router = useRouter();

  useEffect(() => {
    if (status === 'loading') return;
    if (!session || (session.user as any).role !== role) {
      router.replace(LOGIN_PATH[role]);
    }
  }, [session, status, role, router]);

  if (status === 'loading' || !session || (session.user as any).role !== role) {
    return (
      <div className="min-h-screen bg-sand flex items-center justify-center">
        <p className="text-sm text-ink/50">Loading…</p>
      </div>
    );
  }

  return <>{children}</>;
}
