export default function SkylineHero() {
  return (
    <svg viewBox="0 0 900 220" className="w-full h-auto" preserveAspectRatio="xMidYMax slice" aria-hidden="true">
      <defs>
        <linearGradient id="skyfade" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#0F1B2B" stopOpacity="0.05" />
          <stop offset="100%" stopColor="#0F1B2B" stopOpacity="0.9" />
        </linearGradient>
      </defs>
      {/* low skyline blocks */}
      <g fill="url(#skyfade)">
        <rect x="0" y="140" width="40" height="80" />
        <rect x="50" y="110" width="30" height="110" />
        <rect x="90" y="150" width="50" height="70" />
        <rect x="150" y="90" width="24" height="130" />
        <rect x="185" y="130" width="40" height="90" />
        <rect x="240" y="60" width="18" height="160" />
        <rect x="270" y="120" width="46" height="100" />
        {/* Burj-like spire, the tallest element — signature focal point */}
        <polygon points="360,220 372,20 384,220" />
        <rect x="400" y="100" width="30" height="120" />
        <rect x="440" y="150" width="60" height="70" />
        <rect x="510" y="80" width="20" height="140" />
        <rect x="545" y="130" width="44" height="90" />
        <rect x="600" y="60" width="16" height="160" />
        <rect x="630" y="120" width="40" height="100" />
        <rect x="685" y="150" width="55" height="70" />
        <rect x="750" y="95" width="22" height="125" />
        <rect x="785" y="135" width="45" height="85" />
        <rect x="840" y="155" width="35" height="65" />
      </g>
      <rect x="0" y="216" width="900" height="4" fill="#B8925A" opacity="0.8" />
    </svg>
  );
}
