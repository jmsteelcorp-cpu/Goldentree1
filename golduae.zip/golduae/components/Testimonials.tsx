'use client';

import { useEffect, useState } from 'react';

const TESTIMONIALS = [
  {
    quote:
      'The OCR read my title deed in seconds and told me exactly which documents I still needed. No back-and-forth with an agent.',
    name: 'S. Al Marzooqi',
    role: 'Investor, Dubai Marina'
  },
  {
    quote:
      'I tracked my dependents\u2019 visas from my phone the entire time — DLD approval, medical, biometrics, all in one screen.',
    name: 'R. Kapoor',
    role: 'Investor, Downtown Dubai'
  },
  {
    quote: 'As an agent, having a single dashboard for every client\u2019s task list changed how fast we close applications.',
    name: 'F. Haddad',
    role: 'Licensed Agent'
  }
];

export default function Testimonials() {
  const [i, setI] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setI((prev) => (prev + 1) % TESTIMONIALS.length), 5000);
    return () => clearInterval(t);
  }, []);

  const current = TESTIMONIALS[i];

  return (
    <div className="mx-auto max-w-2xl text-center" aria-live="polite">
      <p className="font-display text-xl md:text-2xl leading-relaxed text-night">&ldquo;{current.quote}&rdquo;</p>
      <p className="mt-4 text-sm uppercase tracking-wider text-ink/60">
        {current.name} — {current.role}
      </p>
      <div className="mt-6 flex justify-center gap-2">
        {TESTIMONIALS.map((_, idx) => (
          <button
            key={idx}
            aria-label={`Show testimonial ${idx + 1}`}
            onClick={() => setI(idx)}
            className={`h-1.5 w-6 rounded-full transition-colors ${idx === i ? 'bg-brass' : 'bg-night/15'}`}
          />
        ))}
      </div>
    </div>
  );
}
