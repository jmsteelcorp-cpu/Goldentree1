'use client';

import { useState } from 'react';

export default function FileUploader({
  folder,
  label,
  onUploaded,
  accept = 'image/jpeg,image/png,image/webp,application/pdf'
}: {
  folder: string;
  label: string;
  onUploaded: (url: string) => void;
  accept?: string;
}) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);

  async function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy(true);
    setErr(null);
    setFileName(file.name);

    const fd = new FormData();
    fd.append('file', file);
    fd.append('folder', folder);

    const res = await fetch('/api/upload', { method: 'POST', body: fd });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) {
      setErr(data.error || 'Upload failed.');
      return;
    }
    onUploaded(data.url);
  }

  return (
    <div>
      <label className="label">{label}</label>
      <label className="flex cursor-pointer items-center justify-between rounded-sm border border-dashed border-night/30 bg-white px-4 py-3 text-sm hover:border-brass">
        <span className="text-ink/60">{fileName || 'Choose a file (JPG, PNG or PDF, up to 12MB)'}</span>
        <span className="text-brass-dark underline">{busy ? 'Uploading…' : 'Browse'}</span>
        <input type="file" accept={accept} onChange={handleChange} className="hidden" disabled={busy} />
      </label>
      {err && <p className="mt-1 text-xs text-red-600">{err}</p>}
    </div>
  );
}
