import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        night: '#0F1B2B', // deep desert-night navy — primary dark surface
        sand: '#EDE6D6', // warm sand — primary light surface
        brass: '#B8925A', // antique brass/gold — accent, not the generic terracotta
        'brass-dark': '#8F6B3B',
        emerald: '#1F5C4F', // deep emerald — secondary accent (DLD documents, palm)
        ink: '#161616'
      },
      fontFamily: {
        display: ['var(--font-fraunces)', 'serif'],
        body: ['var(--font-inter)', 'sans-serif'],
        mono: ['var(--font-mono)', 'monospace']
      },
      backgroundImage: {
        horizon: 'linear-gradient(180deg, transparent 0%, rgba(184,146,90,0.12) 100%)'
      }
    }
  },
  plugins: []
};

export default config;
