'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import AuthGate from '@/components/AuthGate';
import StatusBadge from '@/components/StatusBadge';

export default function AdminDashboard() {
  return (
    <AuthGate role="ADMIN">
      <Body />
    </AuthGate>
  );
}

function Body() {
  const [applications, setApplications] = useState<any[]>([]);
  const [filter, setFilter] = useState('ALL');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/applications')
      .then((r) => r.json())
      .then((d) => setApplications(d.applications || []))
      .finally(() => setLoading(false));
  }, []);

  const filtered = filter === 'ALL' ? applications : applications.filter((a) => a.status === filter);

  const statuses = ['ALL', 'DOCS_UNDER_VERIFICATION', 'DOCS_REJECTED', 'IN_PROGRESS', 'COMPLETED', 'SUBMITTED', 'DRAFT'];

  return (
    <main className="min-h-screen bg-sand px-6 py-12">
      <div className="mx-auto max-w-5xl">
        <p className="label">Admin console</p>
        <h1 className="font-display text-3xl text-night mt-1">All applications</h1>

        <div className="mt-6 flex flex-wrap gap-2">
          {statuses.map((s) => (
            <button
              key={s}
              onClick={() => setFilter(s)}
              className={`rounded-full px-3 py-1.5 text-xs ${filter === s ? 'bg-night text-sand' : 'bg-white text-ink/60 border border-night/10'}`}
            >
              {s.replace(/_/g, ' ')}
            </button>
          ))}
        </div>

        {loading ? (
          <p className="mt-6 text-sm text-ink/50">Loading…</p>
        ) : (
          <div className="mt-6 space-y-3">
            {filtered.map((a) => (
              <Link key={a.id} href={`/admin/applications/${a.id}`} className="card flex items-center justify-between hover:border-brass">
                <div>
                  <p className="font-mono text-xs text-ink/50">{a.taskNo}</p>
                  <p className="font-display text-lg text-night mt-1">{a.user?.name || a.user?.email}</p>
                </div>
                <StatusBadge status={a.status} />
              </Link>
            ))}
            {filtered.length === 0 && <p className="text-sm text-ink/50">No applications match this filter.</p>}
          </div>
        )}
      </div>
    </main>
  );
}
