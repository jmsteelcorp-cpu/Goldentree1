'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import AuthGate from '@/components/AuthGate';
import StatusBadge from '@/components/StatusBadge';
import { DOCUMENT_TYPE_LABELS, RELATION_LABELS } from '@/lib/checklist';

export default function AdminApplicationPage() {
  return (
    <AuthGate role="ADMIN">
      <Body />
    </AuthGate>
  );
}

function Body() {
  const { id } = useParams<{ id: string }>();
  const [application, setApplication] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [rejectComment, setRejectComment] = useState<Record<string, string>>({});

  async function load() {
    const res = await fetch(`/api/applications/${id}`);
    const data = await res.json();
    if (res.ok) setApplication(data.application);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, [id]);

  async function verifyDoc(docId: string, decision: 'APPROVED' | 'REJECTED') {
    await fetch(`/api/applications/${id}/documents/${docId}/verify`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ decision, comment: rejectComment[docId] })
    });
    load();
  }

  async function updateStatus(patch: Record<string, string>) {
    await fetch(`/api/admin/applications/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch)
    });
    load();
  }

  if (loading) return <main className="min-h-screen bg-sand flex items-center justify-center text-sm text-ink/50">Loading…</main>;
  if (!application) return <main className="min-h-screen bg-sand flex items-center justify-center text-sm text-ink/50">Not found.</main>;

  return (
    <main className="min-h-screen bg-sand px-6 py-12">
      <div className="mx-auto max-w-3xl">
        <div className="flex items-center justify-between">
          <div>
            <p className="font-mono text-xs text-ink/50">{application.taskNo}</p>
            <h1 className="font-display text-2xl text-night mt-1">{application.user?.name || application.user?.email}</h1>
            <p className="text-xs text-ink/50 mt-1">{application.user?.email} · {application.user?.contactNo}</p>
          </div>
          <StatusBadge status={application.status} />
        </div>

        <div className="mt-8 card">
          <h2 className="font-display text-lg text-night">Documents</h2>
          <div className="mt-4 space-y-4">
            {[...application.documents.map((d: any) => ({ ...d, owner: 'Applicant' })), ...application.dependents.flatMap((dep: any) =>
              dep.documents.map((d: any) => ({ ...d, owner: RELATION_LABELS[dep.relation as keyof typeof RELATION_LABELS] }))
            )].map((d: any) => (
              <div key={d.id} className="border-b border-night/10 pb-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-ink">{DOCUMENT_TYPE_LABELS[d.type as keyof typeof DOCUMENT_TYPE_LABELS]}</p>
                    <p className="text-xs text-ink/40">{d.owner}</p>
                  </div>
                  <StatusBadge status={d.status} />
                </div>
                {d.fileUrl && (
                  <a href={d.fileUrl} target="_blank" className="mt-1 inline-block text-xs text-brass-dark underline">
                    View file
                  </a>
                )}
                {d.fileUrl && d.status === 'UNDER_VERIFICATION' && (
                  <div className="mt-2 flex items-center gap-2">
                    <button onClick={() => verifyDoc(d.id, 'APPROVED')} className="rounded-sm bg-emerald px-3 py-1.5 text-xs text-white">
                      Approve
                    </button>
                    <input
                      placeholder="Rejection comment"
                      className="input flex-1 py-1.5 text-xs"
                      value={rejectComment[d.id] || ''}
                      onChange={(e) => setRejectComment({ ...rejectComment, [d.id]: e.target.value })}
                    />
                    <button onClick={() => verifyDoc(d.id, 'REJECTED')} className="rounded-sm bg-red-600 px-3 py-1.5 text-xs text-white">
                      Reject
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {(application.type === 'INVESTOR_VISA' || application.type === 'DEPENDENT_VISA') && application.status === 'IN_PROGRESS' && (
          <div className="mt-8 card">
            <h2 className="font-display text-lg text-night">Government process</h2>
            <div className="mt-4 space-y-4">
              <StageToggle label="DLD Approval" value={application.dldApproval} onChange={(v) => updateStatus({ dldApproval: v })} />
              <StageToggle label="GDRFA" value={application.gdrfaApproval} onChange={(v) => updateStatus({ gdrfaApproval: v })} />
              <StageToggle label="Medical test" value={application.medicalTest} onChange={(v) => updateStatus({ medicalTest: v })} />
              <StageToggle label="Biometric" value={application.biometric} onChange={(v) => updateStatus({ biometric: v })} />
              <div>
                <label className="label">Emirates ID</label>
                <select
                  className="input"
                  value={application.emiratesIdStatus}
                  onChange={(e) => updateStatus({ emiratesIdStatus: e.target.value })}
                >
                  {['NOT_STARTED', 'PRINTING', 'COURIER', 'DELIVERED'].map((s) => (
                    <option key={s} value={s}>
                      {s.replace('_', ' ')}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label">Estimated completion date</label>
                <input
                  type="date"
                  className="input"
                  defaultValue={application.estimatedCompletionAt ? application.estimatedCompletionAt.slice(0, 10) : ''}
                  onChange={(e) => updateStatus({ estimatedCompletionAt: new Date(e.target.value).toISOString() })}
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}

function StageToggle({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span>{label}</span>
      <div className="flex gap-2">
        {['PENDING', 'APPROVED'].map((s) => (
          <button
            key={s}
            onClick={() => onChange(s)}
            className={`rounded-full px-3 py-1 text-xs ${value === s ? 'bg-night text-sand' : 'bg-white border border-night/10 text-ink/60'}`}
          >
            {s}
          </button>
        ))}
      </div>
    </div>
  );
}
