'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import AuthGate from '@/components/AuthGate';
import FileUploader from '@/components/FileUploader';
import StatusBadge from '@/components/StatusBadge';
import { DOCUMENT_TYPE_LABELS, RELATION_LABELS } from '@/lib/checklist';

export default function AgentApplicationPage() {
  return (
    <AuthGate role="AGENT">
      <Body />
    </AuthGate>
  );
}

function Body() {
  const { id } = useParams<{ id: string }>();
  const [application, setApplication] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  async function load() {
    const res = await fetch(`/api/applications/${id}`);
    const data = await res.json();
    if (res.ok) setApplication(data.application);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, [id]);

  async function handleUpload(docId: string, url: string) {
    await fetch(`/api/documents/${docId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fileUrl: url })
    });
    load();
  }

  if (loading) return <main className="min-h-screen bg-sand flex items-center justify-center text-sm text-ink/50">Loading…</main>;
  if (!application) return <main className="min-h-screen bg-sand flex items-center justify-center text-sm text-ink/50">Not found.</main>;

  const canUpload = ['SUBMITTED', 'DOCS_REJECTED'].includes(application.status);

  return (
    <main className="min-h-screen bg-sand px-6 py-12">
      <div className="mx-auto max-w-2xl">
        <div className="flex items-center justify-between">
          <div>
            <p className="font-mono text-xs text-ink/50">{application.taskNo}</p>
            <h1 className="font-display text-2xl text-night mt-1">{application.user?.name || application.user?.email}</h1>
          </div>
          <StatusBadge status={application.status} />
        </div>

        {canUpload ? (
          <div className="mt-8 card">
            <h2 className="font-display text-lg text-night">Upload documents on client&rsquo;s behalf</h2>
            <div className="mt-4 space-y-5">
              {application.documents.map((d: any) => (
                <div key={d.id}>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-ink/80">{DOCUMENT_TYPE_LABELS[d.type as keyof typeof DOCUMENT_TYPE_LABELS]}</span>
                    {d.fileUrl && <span className="text-xs text-emerald">Uploaded ✓</span>}
                  </div>
                  <div className="mt-1.5">
                    <FileUploader folder="documents" label="" onUploaded={(url) => handleUpload(d.id, url)} />
                  </div>
                </div>
              ))}
              {application.dependents.map((dep: any) => (
                <div key={dep.id}>
                  <p className="text-xs uppercase tracking-wide text-ink/40">
                    Dependent — {RELATION_LABELS[dep.relation as keyof typeof RELATION_LABELS]}
                  </p>
                  {dep.documents.map((d: any) => (
                    <div key={d.id} className="mt-2">
                      <span className="text-sm text-ink/80">{DOCUMENT_TYPE_LABELS[d.type as keyof typeof DOCUMENT_TYPE_LABELS]}</span>
                      <div className="mt-1.5">
                        <FileUploader folder="documents" label="" onUploaded={(url) => handleUpload(d.id, url)} />
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="mt-8 card space-y-3">
            {application.documents.map((d: any) => (
              <div key={d.id} className="flex items-center justify-between text-sm">
                <span>{DOCUMENT_TYPE_LABELS[d.type as keyof typeof DOCUMENT_TYPE_LABELS]}</span>
                <StatusBadge status={d.status} />
              </div>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
