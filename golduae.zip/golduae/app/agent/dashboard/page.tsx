'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';
import AuthGate from '@/components/AuthGate';
import StatusBadge from '@/components/StatusBadge';

export default function AgentDashboard() {
  return (
    <AuthGate role="AGENT">
      <Body />
    </AuthGate>
  );
}

function Body() {
  const { data: session } = useSession();
  const [applications, setApplications] = useState<any[]>([]);
  const [commissions, setCommissions] = useState<{ commissions: any[]; totalEarned: number; totalPending: number }>({
    commissions: [],
    totalEarned: 0,
    totalPending: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch('/api/applications').then((r) => r.json()),
      fetch('/api/agent/commissions').then((r) => r.json())
    ]).then(([apps, comm]) => {
      setApplications(apps.applications || []);
      setCommissions(comm);
      setLoading(false);
    });
  }, []);

  return (
    <main className="min-h-screen bg-sand px-6 py-12">
      <div className="mx-auto max-w-4xl">
        <p className="label">Agent dashboard</p>
        <h1 className="font-display text-3xl text-night mt-1">
          {session?.user?.name ? `Welcome, ${session.user.name}` : 'Welcome'}
        </h1>

        <div className="mt-4 card inline-block">
          <p className="text-xs text-ink/50">Your referral code</p>
          <p className="font-mono text-lg text-brass-dark mt-1">{(session?.user as any)?.agentCode || '—'}</p>
        </div>

        <div className="mt-8 grid gap-4 md:grid-cols-2">
          <div className="card">
            <p className="text-xs text-ink/50">Total commission earned</p>
            <p className="font-display text-2xl text-night mt-1">AED {commissions.totalEarned.toLocaleString('en-AE')}</p>
          </div>
          <div className="card">
            <p className="text-xs text-ink/50">Pending payout</p>
            <p className="font-display text-2xl text-night mt-1">AED {commissions.totalPending.toLocaleString('en-AE')}</p>
          </div>
        </div>

        <div className="mt-10">
          <p className="label">Client applications</p>
          {loading ? (
            <p className="mt-4 text-sm text-ink/50">Loading…</p>
          ) : applications.length === 0 ? (
            <p className="mt-4 text-sm text-ink/50">No client applications linked to your code yet.</p>
          ) : (
            <div className="mt-4 space-y-3">
              {applications.map((a) => (
                <Link key={a.id} href={`/agent/applications/${a.id}`} className="card flex items-center justify-between hover:border-brass">
                  <div>
                    <p className="font-mono text-xs text-ink/50">{a.taskNo}</p>
                    <p className="font-display text-lg text-night mt-1">{a.user?.name || a.user?.email}</p>
                  </div>
                  <StatusBadge status={a.status} />
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
