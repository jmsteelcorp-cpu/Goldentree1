'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function AgentRegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    name: '',
    email: '',
    contactNo: '',
    password: '',
    emiratesIdNo: '',
    bankName: '',
    bankIban: ''
  });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    const res = await fetch('/api/agent/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) {
      setErr(typeof data.error === 'string' ? data.error : 'Please check your details and try again.');
      return;
    }
    router.push(`/user/verify-otp?email=${encodeURIComponent(form.email)}&next=agent`);
  }

  return (
    <main className="min-h-screen bg-night flex items-center justify-center px-6 py-16">
      <div className="w-full max-w-md card bg-white">
        <p className="label">Agent registration</p>
        <h1 className="font-display text-2xl mt-1 text-night">Join as a GoldUAE agent</h1>

        <form onSubmit={submit} className="mt-8 space-y-4">
          <div>
            <label className="label">Agent name</label>
            <input required className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div>
            <label className="label">Email</label>
            <input required type="email" className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </div>
          <div>
            <label className="label">Contact number</label>
            <input required className="input" value={form.contactNo} onChange={(e) => setForm({ ...form, contactNo: e.target.value })} />
          </div>
          <div>
            <label className="label">Emirates ID number</label>
            <input required className="input" value={form.emiratesIdNo} onChange={(e) => setForm({ ...form, emiratesIdNo: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">Bank name</label>
              <input className="input" value={form.bankName} onChange={(e) => setForm({ ...form, bankName: e.target.value })} />
            </div>
            <div>
              <label className="label">IBAN</label>
              <input className="input" value={form.bankIban} onChange={(e) => setForm({ ...form, bankIban: e.target.value })} />
            </div>
          </div>
          <div>
            <label className="label">Password</label>
            <input required type="password" minLength={8} className="input" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          </div>

          {err && <p className="text-sm text-red-600">{err}</p>}

          <button type="submit" disabled={busy} className="btn-primary w-full">
            {busy ? 'Creating account…' : 'Register'}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-ink/60">
          Already registered?{' '}
          <Link href="/agent/login" className="text-brass-dark underline">
            Sign in
          </Link>
        </p>
      </div>
    </main>
  );
}
