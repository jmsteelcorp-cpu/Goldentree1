import Link from 'next/link';
import SkylineHero from '@/components/SkylineHero';
import Testimonials from '@/components/Testimonials';

export default function Home() {
  return (
    <main>
      <section className="relative overflow-hidden bg-night text-sand">
        <div className="mx-auto max-w-5xl px-6 pt-16 pb-4 md:pt-24">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-sm border border-brass flex items-center justify-center font-display text-brass text-lg">G</div>
            <span className="font-display text-lg tracking-wide">GoldUAE</span>
          </div>

          <h1 className="mt-12 max-w-3xl font-display text-4xl md:text-6xl leading-tight">
            The UAE Golden Visa, earned through property you already own.
          </h1>
          <p className="mt-6 max-w-xl text-sand/70 text-base md:text-lg">
            Upload your title deed, get an instant eligibility read, and track every stage of your
            10-year investor visa — from DLD approval to your Emirates ID courier — in one place.
          </p>

          <div className="mt-10 flex flex-wrap gap-4">
            <Link href="/user/apply-visa" className="btn-primary bg-brass hover:bg-brass-dark text-night">
              Apply for Golden Visa
            </Link>
            <Link href="/user/property-valuation" className="inline-flex items-center justify-center rounded-sm border border-sand/40 px-6 py-3 text-sm tracking-wide text-sand hover:bg-sand hover:text-night transition-colors">
              Check Property Eligibility
            </Link>
            <Link href="/user/track" className="inline-flex items-center justify-center px-6 py-3 text-sm tracking-wide text-sand/80 underline underline-offset-4 hover:text-sand">
              Track My Application
            </Link>
          </div>
        </div>
        <SkylineHero />
      </section>

      <div className="skyline-divider bg-sand" />

      <section className="mx-auto max-w-5xl px-6 py-20">
        <p className="label text-center">How it works</p>
        <div className="mt-6 grid gap-8 md:grid-cols-3">
          {[
            {
              step: 'Upload',
              text: 'Upload your title deed or valuation certificate. Our OCR reads the value, developer, and ownership details automatically.'
            },
            {
              step: 'Check',
              text: 'Properties valued at AED 2,000,000 or above qualify. We generate your document checklist instantly — including for any dependents.'
            },
            {
              step: 'Track',
              text: 'Pay securely, then track DLD approval, GDRFA, medical test, biometrics and Emirates ID printing from your dashboard.'
            }
          ].map((s) => (
            <div key={s.step} className="card">
              <h3 className="font-display text-xl text-night">{s.step}</h3>
              <p className="mt-3 text-sm text-ink/70 leading-relaxed">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-white/60 py-20">
        <Testimonials />
      </section>

      <section className="mx-auto max-w-5xl px-6 py-20 grid gap-6 md:grid-cols-2">
        <div className="card">
          <h3 className="font-display text-xl text-night">Are you a real estate agent?</h3>
          <p className="mt-3 text-sm text-ink/70">
            Manage every client&rsquo;s Golden Visa application, upload documents on their behalf, and track your
            commission payouts from a dedicated agent dashboard.
          </p>
          <Link href="/agent/register" className="btn-secondary mt-6">
            Register as an Agent
          </Link>
        </div>
        <div className="card">
          <h3 className="font-display text-xl text-night">Already started an application?</h3>
          <p className="mt-3 text-sm text-ink/70">
            Sign in to your dashboard to upload outstanding documents, make a payment, or check your current
            processing stage.
          </p>
          <Link href="/user/login" className="btn-secondary mt-6">
            Sign In
          </Link>
        </div>
      </section>

      <footer className="border-t border-night/10 py-10 text-center text-xs text-ink/50">
        © {new Date().getFullYear()} GoldUAE. Not a government entity — an independent application concierge service.
      </footer>
    </main>
  );
}
