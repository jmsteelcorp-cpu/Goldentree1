'use client';

import { useEffect, useMemo, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import AuthGate from '@/components/AuthGate';
import { RELATION_LABELS, DOCUMENT_TYPE_LABELS } from '@/lib/checklist';
import { INVESTOR_VISA_PACKAGE_AED, DEPENDENT_VISA_PACKAGE_AED } from '@/lib/pricing';

const RELATIONS = ['PARENT', 'WIFE', 'SISTER', 'DAUGHTER', 'SON', 'SIBLING', 'SERVANT'];

export default function ApplyVisaPage() {
  return (
    <AuthGate role="USER">
      <Body />
    </AuthGate>
  );
}

function Body() {
  const router = useRouter();
  const search = useSearchParams();
  const propertyIdFromQuery = search.get('propertyId');

  const [eligibleProperties, setEligibleProperties] = useState<any[]>([]);
  const [propertyId, setPropertyId] = useState<string | null>(propertyIdFromQuery);
  const [application, setApplication] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const [dependentRelation, setDependentRelation] = useState('WIFE');

  useEffect(() => {
    fetch('/api/properties')
      .then((r) => r.json())
      .then((d) => setEligibleProperties((d.properties || []).filter((p: any) => p.eligibility === 'ELIGIBLE')));
  }, []);

  async function startApplication() {
    if (!propertyId) {
      setErr('Select an eligible property first.');
      return;
    }
    setBusy(true);
    setErr(null);
    const res = await fetch('/api/applications', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 'INVESTOR_VISA', propertyId })
    });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) {
      setErr(data.error || 'Could not start the application.');
      return;
    }
    setApplication(data.application);
    refreshApplication(data.application.id);
  }

  async function refreshApplication(id: string) {
    const res = await fetch(`/api/applications/${id}`);
    const data = await res.json();
    if (res.ok) setApplication(data.application);
  }

  async function addDependent() {
    if (!application) return;
    setBusy(true);
    setErr(null);
    const res = await fetch(`/api/applications/${application.id}/dependents`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ relation: dependentRelation })
    });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) {
      setErr(data.error || 'Could not add dependent.');
      return;
    }
    setApplication(data.application);
  }

  const total = useMemo(() => {
    if (!application) return 0;
    return INVESTOR_VISA_PACKAGE_AED + (application.dependents?.length || 0) * DEPENDENT_VISA_PACKAGE_AED;
  }, [application]);

  return (
    <main className="min-h-screen bg-sand px-6 py-12">
      <div className="mx-auto max-w-2xl">
        <p className="label">Golden Visa Application</p>
        <h1 className="font-display text-3xl text-night mt-1">Investor visa application</h1>

        {!application && (
          <div className="mt-8 card">
            <h2 className="font-display text-lg text-night">1. Choose an eligible property</h2>
            {eligibleProperties.length === 0 ? (
              <p className="mt-3 text-sm text-ink/60">
                No eligible properties yet.{' '}
                <a href="/user/property-valuation" className="text-brass-dark underline">
                  Check a property&rsquo;s eligibility first
                </a>
                .
              </p>
            ) : (
              <div className="mt-3 space-y-2">
                {eligibleProperties.map((p) => (
                  <label key={p.id} className="flex items-center gap-3 rounded-sm border border-night/10 px-4 py-3 text-sm cursor-pointer has-[:checked]:border-brass">
                    <input type="radio" name="property" checked={propertyId === p.id} onChange={() => setPropertyId(p.id)} />
                    <span>
                      {p.projectName || 'Property'} — AED {p.value?.toLocaleString('en-AE')}
                    </span>
                  </label>
                ))}
              </div>
            )}
            {err && <p className="mt-3 text-sm text-red-600">{err}</p>}
            <button disabled={busy || !propertyId} onClick={startApplication} className="btn-primary mt-6">
              {busy ? 'Starting…' : 'Start application'}
            </button>
          </div>
        )}

        {application && (
          <>
            <div className="mt-8 card">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg text-night">2. Add dependents (optional)</h2>
                <span className="font-mono text-xs text-ink/50">{application.taskNo}</span>
              </div>
              <div className="mt-4 flex items-end gap-3">
                <div className="flex-1">
                  <label className="label">Relationship</label>
                  <select className="input" value={dependentRelation} onChange={(e) => setDependentRelation(e.target.value)}>
                    {RELATIONS.map((r) => (
                      <option key={r} value={r}>
                        {RELATION_LABELS[r as keyof typeof RELATION_LABELS]}
                      </option>
                    ))}
                  </select>
                </div>
                <button disabled={busy} onClick={addDependent} className="btn-secondary">
                  Add dependant
                </button>
              </div>

              {application.dependents?.length > 0 && (
                <ul className="mt-4 space-y-1 text-sm text-ink/70">
                  {application.dependents.map((d: any) => (
                    <li key={d.id}>• {RELATION_LABELS[d.relation as keyof typeof RELATION_LABELS]}</li>
                  ))}
                </ul>
              )}
            </div>

            <div className="mt-8 card">
              <h2 className="font-display text-lg text-night">3. Document checklist</h2>
              <p className="mt-1 text-xs text-ink/50">You&rsquo;ll upload these after payment, from your dashboard.</p>
              <ul className="mt-4 space-y-1.5 text-sm text-ink/80">
                {application.documents?.map((d: any) => (
                  <li key={d.id}>• {DOCUMENT_TYPE_LABELS[d.type as keyof typeof DOCUMENT_TYPE_LABELS]}</li>
                ))}
              </ul>
            </div>

            <PaymentPanel application={application} total={total} onPaid={() => router.push(`/user/track/${application.id}`)} />
          </>
        )}
      </div>
    </main>
  );
}

function PaymentPanel({ application, total, onPaid }: { application: any; total: number; onPaid: () => void }) {
  const [billingName, setBillingName] = useState('');
  const [agentCode, setAgentCode] = useState('');
  const [method, setMethod] = useState<'CARD' | 'BANK_TRANSFER'>('CARD');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function pay() {
    if (!billingName) {
      setErr('Billing name is required.');
      return;
    }
    setBusy(true);
    setErr(null);
    const res = await fetch('/api/payments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ applicationId: application.id, billingName, agentCode: agentCode || undefined, method })
    });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) {
      setErr(data.error || 'Payment failed.');
      return;
    }
    onPaid();
  }

  return (
    <div className="mt-8 card">
      <h2 className="font-display text-lg text-night">4. Payment</h2>
      <div className="mt-4 flex items-center justify-between text-sm">
        <span className="text-ink/60">Investor Golden Visa package</span>
        <span>AED {(130000).toLocaleString('en-AE')}</span>
      </div>
      {application.dependents?.length > 0 && (
        <div className="mt-1 flex items-center justify-between text-sm">
          <span className="text-ink/60">Dependent visa × {application.dependents.length}</span>
          <span>AED {(application.dependents.length * 7000).toLocaleString('en-AE')}</span>
        </div>
      )}
      <div className="mt-3 flex items-center justify-between border-t border-night/10 pt-3 font-medium">
        <span>Total</span>
        <span>AED {total.toLocaleString('en-AE')}</span>
      </div>

      <div className="mt-6 space-y-4">
        <div>
          <label className="label">Billing name</label>
          <input className="input" value={billingName} onChange={(e) => setBillingName(e.target.value)} />
        </div>
        <div>
          <label className="label">Agent code (optional)</label>
          <input className="input" value={agentCode} onChange={(e) => setAgentCode(e.target.value.toUpperCase())} />
        </div>
        <div>
          <label className="label">Payment method</label>
          <div className="flex gap-3">
            {(['CARD', 'BANK_TRANSFER'] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setMethod(m)}
                className={`flex-1 rounded-sm border px-4 py-2.5 text-sm ${method === m ? 'border-brass bg-brass/10' : 'border-night/15'}`}
              >
                {m === 'CARD' ? 'Card' : 'Bank transfer'}
              </button>
            ))}
          </div>
        </div>
        {err && <p className="text-sm text-red-600">{err}</p>}
        <button disabled={busy} onClick={pay} className="btn-primary w-full">
          {busy ? 'Processing payment…' : `Pay AED ${total.toLocaleString('en-AE')}`}
        </button>
        <p className="text-center text-xs text-ink/40">Mock payment for this prototype — no real charge is made.</p>
      </div>
    </div>
  );
}
