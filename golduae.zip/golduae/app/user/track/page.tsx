'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import AuthGate from '@/components/AuthGate';
import StatusBadge from '@/components/StatusBadge';

export default function TrackListPage() {
  return (
    <AuthGate role="USER">
      <Body />
    </AuthGate>
  );
}

function Body() {
  const [applications, setApplications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/applications')
      .then((r) => r.json())
      .then((d) => setApplications(d.applications || []))
      .finally(() => setLoading(false));
  }, []);

  return (
    <main className="min-h-screen bg-sand px-6 py-12">
      <div className="mx-auto max-w-3xl">
        <p className="label">Track</p>
        <h1 className="font-display text-3xl text-night mt-1">Your applications</h1>

        {loading ? (
          <p className="mt-6 text-sm text-ink/50">Loading…</p>
        ) : applications.length === 0 ? (
          <p className="mt-6 text-sm text-ink/50">
            No applications yet.{' '}
            <Link href="/user/apply-visa" className="text-brass-dark underline">
              Start one
            </Link>
            .
          </p>
        ) : (
          <div className="mt-6 space-y-3">
            {applications.map((a) => (
              <Link key={a.id} href={`/user/track/${a.id}`} className="card flex items-center justify-between hover:border-brass">
                <div>
                  <p className="font-mono text-xs text-ink/50">{a.taskNo}</p>
                  <p className="font-display text-lg text-night mt-1">{typeLabel(a.type)}</p>
                </div>
                <StatusBadge status={a.status} />
              </Link>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}

function typeLabel(t: string) {
  return { INVESTOR_VISA: 'Investor Golden Visa', DEPENDENT_VISA: 'Dependent Visa', PROPERTY_VALUATION: 'Property Valuation' }[t] || t;
}
