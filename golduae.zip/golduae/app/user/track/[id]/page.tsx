'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import AuthGate from '@/components/AuthGate';
import FileUploader from '@/components/FileUploader';
import StatusBadge from '@/components/StatusBadge';
import { DOCUMENT_TYPE_LABELS, RELATION_LABELS } from '@/lib/checklist';

export default function TrackDetailPage() {
  return (
    <AuthGate role="USER">
      <Body />
    </AuthGate>
  );
}

function Body() {
  const { id } = useParams<{ id: string }>();
  const [application, setApplication] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [submitErr, setSubmitErr] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function load() {
    const res = await fetch(`/api/applications/${id}`);
    const data = await res.json();
    if (res.ok) setApplication(data.application);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, [id]);

  async function handleUpload(docId: string, url: string) {
    await fetch(`/api/documents/${docId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fileUrl: url })
    });
    load();
  }

  async function submitDocuments() {
    setSubmitting(true);
    setSubmitErr(null);
    const res = await fetch(`/api/applications/${id}/submit-documents`, { method: 'POST' });
    const data = await res.json();
    setSubmitting(false);
    if (!res.ok) {
      setSubmitErr(data.error);
      return;
    }
    load();
  }

  if (loading) return <main className="min-h-screen bg-sand flex items-center justify-center text-sm text-ink/50">Loading…</main>;
  if (!application) return <main className="min-h-screen bg-sand flex items-center justify-center text-sm text-ink/50">Application not found.</main>;

  const canUpload = ['SUBMITTED', 'DOCS_REJECTED'].includes(application.status);
  const allUploaded = application.documents.every((d: any) => d.fileUrl);

  return (
    <main className="min-h-screen bg-sand px-6 py-12">
      <div className="mx-auto max-w-2xl">
        <div className="flex items-center justify-between">
          <div>
            <p className="font-mono text-xs text-ink/50">{application.taskNo}</p>
            <h1 className="font-display text-2xl text-night mt-1">{typeLabel(application.type)}</h1>
          </div>
          <StatusBadge status={application.status} />
        </div>

        {application.payment?.invoiceUrl && (
          <a href={application.payment.invoiceUrl} target="_blank" className="mt-4 inline-block text-sm text-brass-dark underline">
            Download invoice / receipt (PDF)
          </a>
        )}

        {application.status === 'DRAFT' && (
          <p className="mt-6 card text-sm text-ink/60">This application hasn&rsquo;t been paid yet — complete payment to unlock document upload.</p>
        )}

        {canUpload && (
          <div className="mt-8 card">
            <h2 className="font-display text-lg text-night">Upload documents</h2>
            <div className="mt-4 space-y-5">
              {application.documents.map((d: any) => (
                <DocRow key={d.id} doc={d} onUpload={(url) => handleUpload(d.id, url)} />
              ))}
              {application.dependents.map((dep: any) => (
                <div key={dep.id}>
                  <p className="mt-2 text-xs uppercase tracking-wide text-ink/40">
                    Dependent — {RELATION_LABELS[dep.relation as keyof typeof RELATION_LABELS]}
                  </p>
                  {dep.documents.map((d: any) => (
                    <DocRow key={d.id} doc={d} onUpload={(url) => handleUpload(d.id, url)} />
                  ))}
                </div>
              ))}
            </div>

            {submitErr && <p className="mt-4 text-sm text-red-600">{submitErr}</p>}
            <button disabled={!allUploaded || submitting} onClick={submitDocuments} className="btn-primary mt-6">
              {submitting ? 'Submitting…' : 'Submit documents for verification'}
            </button>
          </div>
        )}

        {['DOCS_UNDER_VERIFICATION', 'IN_PROGRESS', 'COMPLETED'].includes(application.status) && (
          <div className="mt-8 card">
            <h2 className="font-display text-lg text-night">Document status</h2>
            <div className="mt-4 space-y-3">
              {application.documents.map((d: any) => (
                <div key={d.id} className="flex items-center justify-between text-sm">
                  <span>{DOCUMENT_TYPE_LABELS[d.type as keyof typeof DOCUMENT_TYPE_LABELS]}</span>
                  <StatusBadge status={d.status} />
                </div>
              ))}
            </div>
            {application.documents.some((d: any) => d.status === 'REJECTED') && (
              <div className="mt-4 rounded-sm bg-red-50 p-3 text-xs text-red-700">
                Some documents were rejected — re-upload them above.
                {application.documents
                  .filter((d: any) => d.rejectionComment)
                  .map((d: any) => (
                    <p key={d.id} className="mt-1">
                      • {DOCUMENT_TYPE_LABELS[d.type as keyof typeof DOCUMENT_TYPE_LABELS]}: {d.rejectionComment}
                    </p>
                  ))}
              </div>
            )}
          </div>
        )}

        {(application.type === 'INVESTOR_VISA' || application.type === 'DEPENDENT_VISA') &&
          ['IN_PROGRESS', 'COMPLETED'].includes(application.status) && <ProcessTimeline application={application} />}
      </div>
    </main>
  );
}

function DocRow({ doc, onUpload }: { doc: any; onUpload: (url: string) => void }) {
  return (
    <div>
      <div className="flex items-center justify-between">
        <span className="text-sm text-ink/80">{DOCUMENT_TYPE_LABELS[doc.type as keyof typeof DOCUMENT_TYPE_LABELS]}</span>
        {doc.fileUrl && <span className="text-xs text-emerald">Uploaded ✓</span>}
      </div>
      {doc.rejectionComment && <p className="mt-1 text-xs text-red-600">Rejected: {doc.rejectionComment}</p>}
      <div className="mt-1.5">
        <FileUploader folder="documents" label="" onUploaded={onUpload} />
      </div>
    </div>
  );
}

function ProcessTimeline({ application }: { application: any }) {
  const steps = [
    { label: 'DLD Approval', value: application.dldApproval },
    { label: 'GDRFA', value: application.gdrfaApproval },
    { label: 'Medical test', value: application.medicalTest, note: application.medicalTestNote },
    { label: 'Biometric', value: application.biometric, note: application.biometricNote },
    { label: 'Emirates ID', value: application.emiratesIdStatus }
  ];

  return (
    <div className="mt-8 card">
      <h2 className="font-display text-lg text-night">Government process</h2>
      {application.estimatedCompletionAt && (
        <p className="mt-1 text-xs text-ink/50">
          Estimated completion: {new Date(application.estimatedCompletionAt).toLocaleDateString('en-GB')}
        </p>
      )}
      <div className="mt-4 space-y-3">
        {steps.map((s) => (
          <div key={s.label}>
            <div className="flex items-center justify-between text-sm">
              <span>{s.label}</span>
              <StatusBadge status={s.value} />
            </div>
            {s.note && <p className="mt-1 text-xs text-ink/50">{s.note}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}

function typeLabel(t: string) {
  return { INVESTOR_VISA: 'Investor Golden Visa', DEPENDENT_VISA: 'Dependent Visa', PROPERTY_VALUATION: 'Property Valuation' }[t] || t;
}
