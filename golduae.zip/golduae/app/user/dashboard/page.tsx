'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import AuthGate from '@/components/AuthGate';
import StatusBadge from '@/components/StatusBadge';

export default function UserDashboard() {
  return (
    <AuthGate role="USER">
      <DashboardBody />
    </AuthGate>
  );
}

function DashboardBody() {
  const { data: session } = useSession();
  const [applications, setApplications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/applications')
      .then((r) => r.json())
      .then((d) => setApplications(d.applications || []))
      .finally(() => setLoading(false));
  }, []);

  return (
    <main className="min-h-screen bg-sand px-6 py-12">
      <div className="mx-auto max-w-4xl">
        <p className="label">Dashboard</p>
        <h1 className="font-display text-3xl text-night mt-1">
          Welcome{session?.user?.name ? `, ${session.user.name}` : ''}
        </h1>

        <div className="mt-8 grid gap-4 md:grid-cols-3">
          <Link href="/user/property-valuation" className="card hover:border-brass">
            <h3 className="font-display text-lg text-night">Property Valuation</h3>
            <p className="mt-2 text-sm text-ink/60">Upload a title deed and check Golden Visa eligibility.</p>
          </Link>
          <Link href="/user/apply-visa" className="card hover:border-brass">
            <h3 className="font-display text-lg text-night">Apply for Golden Visa</h3>
            <p className="mt-2 text-sm text-ink/60">Start an investor or dependent visa application.</p>
          </Link>
          <Link href="/user/track" className="card hover:border-brass">
            <h3 className="font-display text-lg text-night">Track Applications</h3>
            <p className="mt-2 text-sm text-ink/60">See document status and government process stages.</p>
          </Link>
        </div>

        <div className="mt-12">
          <p className="label">Your applications</p>
          {loading ? (
            <p className="mt-4 text-sm text-ink/50">Loading…</p>
          ) : applications.length === 0 ? (
            <p className="mt-4 text-sm text-ink/50">No applications yet — start one above.</p>
          ) : (
            <div className="mt-4 space-y-3">
              {applications.map((a) => (
                <Link key={a.id} href={`/user/track/${a.id}`} className="card flex items-center justify-between hover:border-brass">
                  <div>
                    <p className="font-mono text-xs text-ink/50">{a.taskNo}</p>
                    <p className="font-display text-lg text-night mt-1">{typeLabel(a.type)}</p>
                  </div>
                  <StatusBadge status={a.status} />
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </main>
  );
}

function typeLabel(t: string) {
  return { INVESTOR_VISA: 'Investor Golden Visa', DEPENDENT_VISA: 'Dependent Visa', PROPERTY_VALUATION: 'Property Valuation' }[t] || t;
}
