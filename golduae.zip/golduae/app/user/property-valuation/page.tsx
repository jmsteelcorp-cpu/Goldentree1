'use client';

import { useState } from 'react';
import Link from 'next/link';
import AuthGate from '@/components/AuthGate';
import FileUploader from '@/components/FileUploader';

export default function PropertyValuationPage() {
  return (
    <AuthGate role="USER">
      <Body />
    </AuthGate>
  );
}

function Body() {
  const [deedUrl, setDeedUrl] = useState<string | null>(null);
  const [property, setProperty] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [minRequired, setMinRequired] = useState(2_000_000);

  async function runCheck(url: string) {
    setDeedUrl(url);
    setBusy(true);
    setErr(null);
    try {
      const createRes = await fetch('/api/properties', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ titleDeedUrl: url })
      });
      const createData = await createRes.json();
      if (!createRes.ok) throw new Error(createData.error || 'Could not save the title deed.');

      const ocrRes = await fetch(`/api/properties/${createData.property.id}/ocr`, { method: 'POST' });
      const ocrData = await ocrRes.json();
      if (!ocrRes.ok) throw new Error(ocrData.error || 'OCR could not read this document.');

      setProperty(ocrData.property);
      setMinRequired(ocrData.minRequired);
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="min-h-screen bg-sand px-6 py-12">
      <div className="mx-auto max-w-2xl">
        <p className="label">Property Valuation</p>
        <h1 className="font-display text-3xl text-night mt-1">Check your Golden Visa eligibility</h1>
        <p className="mt-3 text-sm text-ink/60">
          Upload your title deed. We&rsquo;ll read the property value, developer, and ownership details
          automatically — properties valued at AED {minRequired.toLocaleString('en-AE')} or above qualify.
        </p>

        <div className="mt-8 card">
          <FileUploader folder="title-deeds" label="Upload title deed / valuation certificate" onUploaded={runCheck} />
          {busy && <p className="mt-3 text-sm text-ink/50">Reading your document…</p>}
          {err && <p className="mt-3 text-sm text-red-600">{err}</p>}
        </div>

        {property && (
          <div className="mt-8 card">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl text-night">Extracted details</h2>
              <span
                className={`rounded-full px-3 py-1 text-xs font-medium ${
                  property.eligibility === 'ELIGIBLE'
                    ? 'bg-emerald/15 text-emerald'
                    : property.eligibility === 'NOT_ELIGIBLE'
                    ? 'bg-red-100 text-red-700'
                    : 'bg-ink/10 text-ink/60'
                }`}
              >
                {property.eligibility === 'ELIGIBLE' ? 'Eligible' : property.eligibility === 'NOT_ELIGIBLE' ? 'Not eligible' : 'Review needed'}
              </span>
            </div>

            <dl className="mt-4 grid grid-cols-2 gap-y-3 text-sm">
              <Field label="Value (AED)" value={property.value ? property.value.toLocaleString('en-AE') : '—'} />
              <Field label="Owner name" value={property.ownerName || '—'} />
              <Field label="Property type" value={property.propertyType || '—'} />
              <Field label="Developer" value={property.developerName || '—'} />
              <Field label="Project" value={property.projectName || '—'} />
              <Field label="Purchase date" value={property.purchaseDate ? new Date(property.purchaseDate).toLocaleDateString('en-GB') : '—'} />
              <Field label="Mortgaged" value={property.hasMortgage == null ? '—' : property.hasMortgage ? 'Yes' : 'No'} />
              <Field label="Off-plan" value={property.isOffPlan == null ? '—' : property.isOffPlan ? 'Yes' : 'Ready'} />
            </dl>

            {property.ocrConfidence != null && property.ocrConfidence < 0.6 && (
              <p className="mt-4 text-xs text-brass-dark">
                Some fields could not be read confidently from this document. Double-check the figures above, or
                upload a clearer scan.
              </p>
            )}

            <div className="mt-6">
              {property.eligibility === 'ELIGIBLE' ? (
                <Link href={`/user/apply-visa?propertyId=${property.id}`} className="btn-primary">
                  Continue to Golden Visa application
                </Link>
              ) : property.eligibility === 'NOT_ELIGIBLE' ? (
                <p className="text-sm text-ink/60">
                  This property&rsquo;s value falls below the AED {minRequired.toLocaleString('en-AE')} threshold required
                  for the investor Golden Visa.
                </p>
              ) : (
                <p className="text-sm text-ink/60">We couldn&rsquo;t confidently read the property value — try a clearer upload.</p>
              )}
            </div>
          </div>
        )}
      </div>
    </main>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs uppercase tracking-wide text-ink/40">{label}</dt>
      <dd className="mt-0.5 text-ink">{value}</dd>
    </div>
  );
}
