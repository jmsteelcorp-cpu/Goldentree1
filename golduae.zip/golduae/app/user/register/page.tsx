'use client';

import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';

export default function RegisterPage() {
  const router = useRouter();
  const search = useSearchParams();
  const [form, setForm] = useState({
    name: '',
    email: '',
    contactNo: '',
    password: '',
    agentCode: search.get('ref') || ''
  });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) {
      setErr(typeof data.error === 'string' ? data.error : 'Please check your details and try again.');
      return;
    }
    router.push(`/user/verify-otp?email=${encodeURIComponent(form.email)}`);
  }

  return (
    <main className="min-h-screen bg-night flex items-center justify-center px-6 py-16">
      <div className="w-full max-w-md card bg-white">
        <p className="label">Create your account</p>
        <h1 className="font-display text-2xl mt-1 text-night">Start your Golden Visa application</h1>

        <form onSubmit={submit} className="mt-8 space-y-4">
          <div>
            <label className="label">Full name</label>
            <input required className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div>
            <label className="label">Email</label>
            <input required type="email" className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </div>
          <div>
            <label className="label">Contact number</label>
            <input required className="input" value={form.contactNo} onChange={(e) => setForm({ ...form, contactNo: e.target.value })} />
          </div>
          <div>
            <label className="label">Password</label>
            <input required type="password" minLength={8} className="input" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
            <p className="mt-1 text-xs text-ink/50">At least 8 characters.</p>
          </div>
          <div>
            <label className="label">Agent referral code (optional)</label>
            <input className="input" value={form.agentCode} onChange={(e) => setForm({ ...form, agentCode: e.target.value.toUpperCase() })} />
          </div>

          {err && <p className="text-sm text-red-600">{err}</p>}

          <button type="submit" disabled={busy} className="btn-primary w-full">
            {busy ? 'Creating account…' : 'Create account'}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-ink/60">
          Already have an account?{' '}
          <Link href="/user/login" className="text-brass-dark underline">
            Sign in
          </Link>
        </p>
      </div>
    </main>
  );
}
