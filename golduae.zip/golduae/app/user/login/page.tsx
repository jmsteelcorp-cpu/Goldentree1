'use client';

import { useState } from 'react';
import { signIn } from 'next-auth/react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';

export default function LoginPage() {
  const router = useRouter();
  const search = useSearchParams();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    const res = await signIn('credentials', { email, password, redirect: false });
    setBusy(false);
    if (res?.error) {
      setErr(
        res.error === 'EMAIL_NOT_VERIFIED'
          ? 'Please verify your email before signing in.'
          : 'Incorrect email or password.'
      );
      return;
    }
    router.push('/user/dashboard');
  }

  return (
    <main className="min-h-screen bg-night flex items-center justify-center px-6 py-16">
      <div className="w-full max-w-sm card bg-white">
        <p className="label">Sign in</p>
        <h1 className="font-display text-2xl mt-1 text-night">Welcome back</h1>
        {search.get('verified') && <p className="mt-2 text-sm text-emerald">Email verified — sign in below.</p>}

        <form onSubmit={submit} className="mt-6 space-y-4">
          <div>
            <label className="label">Email</label>
            <input required type="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div>
            <label className="label">Password</label>
            <input required type="password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          {err && <p className="text-sm text-red-600">{err}</p>}
          <button type="submit" disabled={busy} className="btn-primary w-full">
            {busy ? 'Signing in…' : 'Sign in'}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-ink/60">
          New here?{' '}
          <Link href="/user/register" className="text-brass-dark underline">
            Create an account
          </Link>
        </p>
      </div>
    </main>
  );
}
