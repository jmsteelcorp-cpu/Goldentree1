'use client';

import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';

export default function VerifyOtpPage() {
  const router = useRouter();
  const search = useSearchParams();
  const email = search.get('email') || '';
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [resent, setResent] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    const res = await fetch('/api/auth/verify-otp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, code })
    });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) {
      setErr(data.error || 'Verification failed.');
      return;
    }
    router.push('/user/login?verified=1');
  }

  async function resend() {
    setResent(false);
    await fetch('/api/auth/send-otp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email })
    });
    setResent(true);
  }

  return (
    <main className="min-h-screen bg-night flex items-center justify-center px-6 py-16">
      <div className="w-full max-w-sm card bg-white">
        <p className="label">Verify your email</p>
        <h1 className="font-display text-2xl mt-1 text-night">Enter your code</h1>
        <p className="mt-2 text-sm text-ink/60">We sent a 6-digit code to {email || 'your email'}.</p>

        <form onSubmit={submit} className="mt-6 space-y-4">
          <input
            required
            maxLength={6}
            inputMode="numeric"
            className="input text-center text-2xl tracking-[0.5em] font-mono"
            value={code}
            onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
            placeholder="······"
          />
          {err && <p className="text-sm text-red-600">{err}</p>}
          <button type="submit" disabled={busy || code.length !== 6} className="btn-primary w-full">
            {busy ? 'Verifying…' : 'Verify & continue'}
          </button>
        </form>

        <button onClick={resend} className="mt-4 w-full text-center text-sm text-brass-dark underline">
          Resend code
        </button>
        {resent && <p className="mt-2 text-center text-xs text-emerald">A new code was sent.</p>}
      </div>
    </main>
  );
}
