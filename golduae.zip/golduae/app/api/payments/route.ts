import { NextResponse } from 'next/server';
import { z } from 'zod';
import { put } from '@vercel/blob';
import { prisma } from '@/lib/prisma';
import { requireSession } from '@/lib/authz';
import { calculateInvoiceTotal, calculateCommission } from '@/lib/pricing';
import { generateInvoicePdf } from '@/lib/pdf';

const schema = z.object({
  applicationId: z.string(),
  billingName: z.string().min(2),
  agentCode: z.string().optional(),
  method: z.enum(['CARD', 'BANK_TRANSFER'])
});

export async function POST(req: Request) {
  const { session, error } = await requireSession();
  if (error) return error;

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Invalid input' }, { status: 400 });

  const { applicationId, billingName, agentCode, method } = parsed.data;

  const application = await prisma.application.findUnique({
    where: { id: applicationId },
    include: { dependents: true, payment: true, agent: true }
  });
  if (!application || application.userId !== (session!.user as any).id) {
    return NextResponse.json({ error: 'Application not found' }, { status: 404 });
  }
  if (application.payment) {
    return NextResponse.json({ error: 'This application has already been paid.' }, { status: 400 });
  }

  const { investor, dependents, total } =
    application.type === 'PROPERTY_VALUATION'
      ? { investor: 0, dependents: 0, total: 0 }
      : calculateInvoiceTotal(application.dependents.length);

  // NOTE: this is a mock payment flow — it marks the payment PAID immediately
  // instead of calling a real payment gateway (Stripe/Telr/PayTabs). Swap the
  // block below for a real charge + webhook confirmation when ready.
  const payment = await prisma.payment.create({
    data: {
      applicationId: application.id,
      billingName,
      agentCode,
      method,
      amountAed: total,
      status: 'PAID',
      paidAt: new Date()
    }
  });

  const lines = [
    { label: 'Investor Golden Visa package', amountAed: investor },
    ...(dependents > 0 ? [{ label: `Dependent visa package × ${application.dependents.length}`, amountAed: dependents }] : [])
  ].filter((l) => l.amountAed > 0);

  const pdfBytes = await generateInvoicePdf({
    invoiceNo: application.taskNo,
    billingName,
    agentCode,
    lines: lines.length ? lines : [{ label: 'Property valuation service', amountAed: 0 }],
    total,
    paid: true
  });

  const blob = await put(`invoices/${application.id}.pdf`, new Blob([pdfBytes], { type: 'application/pdf' }), {
    access: 'public'
  });

  await prisma.payment.update({ where: { id: payment.id }, data: { invoiceUrl: blob.url, receiptUrl: blob.url } });

  await prisma.application.update({
    where: { id: application.id },
    data: { status: 'SUBMITTED' }
  });

  if (application.agentId && total > 0) {
    await prisma.commission.create({
      data: {
        agentId: application.agentId,
        applicationId: application.id,
        amountAed: calculateCommission(total)
      }
    });
  }

  return NextResponse.json({ invoiceUrl: blob.url, total });
}
