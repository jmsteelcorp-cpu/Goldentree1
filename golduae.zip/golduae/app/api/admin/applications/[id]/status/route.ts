import { NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireRole } from '@/lib/authz';

const schema = z.object({
  dldApproval: z.enum(['PENDING', 'APPROVED']).optional(),
  gdrfaApproval: z.enum(['PENDING', 'APPROVED']).optional(),
  medicalTest: z.enum(['PENDING', 'APPROVED']).optional(),
  medicalTestNote: z.string().optional(),
  biometric: z.enum(['PENDING', 'APPROVED']).optional(),
  biometricNote: z.string().optional(),
  emiratesIdStatus: z.enum(['NOT_STARTED', 'PRINTING', 'COURIER', 'DELIVERED']).optional(),
  estimatedCompletionAt: z.string().optional()
});

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const { error } = await requireRole('ADMIN');
  if (error) return error;

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Invalid input' }, { status: 400 });

  const data: any = { ...parsed.data };
  if (data.estimatedCompletionAt) data.estimatedCompletionAt = new Date(data.estimatedCompletionAt);

  const isFullyDone =
    (parsed.data.dldApproval ?? undefined) === 'APPROVED' &&
    (parsed.data.gdrfaApproval ?? undefined) === 'APPROVED' &&
    (parsed.data.medicalTest ?? undefined) === 'APPROVED' &&
    (parsed.data.biometric ?? undefined) === 'APPROVED' &&
    (parsed.data.emiratesIdStatus ?? undefined) === 'DELIVERED';

  if (isFullyDone) data.status = 'COMPLETED';

  const application = await prisma.application.update({
    where: { id: params.id },
    data
  });

  return NextResponse.json({ application });
}
