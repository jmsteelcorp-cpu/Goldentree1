import { NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireSession } from '@/lib/authz';

const schema = z.object({
  titleDeedUrl: z.string().url(),
  valuationUrl: z.string().url().optional()
});

export async function POST(req: Request) {
  const { session, error } = await requireSession();
  if (error) return error;

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Invalid input' }, { status: 400 });

  const property = await prisma.property.create({
    data: {
      userId: (session!.user as any).id,
      titleDeedUrl: parsed.data.titleDeedUrl,
      valuationUrl: parsed.data.valuationUrl
    }
  });

  return NextResponse.json({ property });
}

export async function GET() {
  const { session, error } = await requireSession();
  if (error) return error;

  const properties = await prisma.property.findMany({
    where: { userId: (session!.user as any).id },
    orderBy: { createdAt: 'desc' }
  });

  return NextResponse.json({ properties });
}
