import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireSession } from '@/lib/authz';
import { runDeedOcr, GOLDEN_VISA_MIN_PROPERTY_VALUE_AED } from '@/lib/ocr';

export const runtime = 'nodejs';
export const maxDuration = 60;

export async function POST(_req: Request, { params }: { params: { id: string } }) {
  const { session, error } = await requireSession();
  if (error) return error;

  const property = await prisma.property.findUnique({ where: { id: params.id } });
  if (!property || property.userId !== (session!.user as any).id) {
    return NextResponse.json({ error: 'Property not found' }, { status: 404 });
  }

  // Fetch the stored deed image/PDF and hand it to Vision as base64.
  const fileRes = await fetch(property.titleDeedUrl);
  if (!fileRes.ok) {
    return NextResponse.json({ error: 'Could not read the uploaded title deed file.' }, { status: 502 });
  }
  const arrayBuffer = await fileRes.arrayBuffer();
  const base64 = Buffer.from(arrayBuffer).toString('base64');

  let parsed;
  try {
    parsed = await runDeedOcr(base64);
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'OCR failed' }, { status: 502 });
  }

  const eligible = (parsed.value ?? 0) >= GOLDEN_VISA_MIN_PROPERTY_VALUE_AED;

  const updated = await prisma.property.update({
    where: { id: property.id },
    data: {
      ocrRawText: parsed.rawText,
      ocrConfidence: parsed.confidence,
      value: parsed.value,
      ownerName: parsed.ownerName,
      propertyType: parsed.propertyType,
      developerName: parsed.developerName,
      projectName: parsed.projectName,
      purchaseDate: parsed.purchaseDate ? new Date(parsed.purchaseDate) : null,
      hasMortgage: parsed.hasMortgage,
      isOffPlan: parsed.isOffPlan,
      paymentPlanWithDeveloper: parsed.paymentPlanWithDeveloper,
      eligibility: parsed.value == null ? 'PENDING' : eligible ? 'ELIGIBLE' : 'NOT_ELIGIBLE'
    }
  });

  return NextResponse.json({ property: updated, minRequired: GOLDEN_VISA_MIN_PROPERTY_VALUE_AED });
}
