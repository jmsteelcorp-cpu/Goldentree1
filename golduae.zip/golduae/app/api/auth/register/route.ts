import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { issueOtp } from '@/lib/otp';

const schema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  contactNo: z.string().min(6),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  agentCode: z.string().optional()
});

export async function POST(req: Request) {
  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const { name, email, contactNo, password, agentCode } = parsed.data;

  const existing = await prisma.user.findUnique({ where: { email: email.toLowerCase().trim() } });
  if (existing) {
    return NextResponse.json({ error: 'An account with this email already exists.' }, { status: 409 });
  }

  let referredByAgentId: string | undefined;
  if (agentCode) {
    const agent = await prisma.agent.findUnique({ where: { agentCode: agentCode.toUpperCase() } });
    if (agent) referredByAgentId = agent.id;
  }

  const passwordHash = await bcrypt.hash(password, 12);

  const user = await prisma.user.create({
    data: {
      name,
      email: email.toLowerCase().trim(),
      contactNo,
      passwordHash,
      role: 'USER',
      referredByAgentId
    }
  });

  await issueOtp(user.id, 'REGISTER_VERIFY', user.email);

  return NextResponse.json({ ok: true, userId: user.id, email: user.email });
}
