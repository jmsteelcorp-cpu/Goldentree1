import { NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { verifyOtp } from '@/lib/otp';

const schema = z.object({
  email: z.string().email(),
  code: z.string().length(6)
});

export async function POST(req: Request) {
  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Invalid input' }, { status: 400 });

  const { email, code } = parsed.data;
  const user = await prisma.user.findUnique({ where: { email: email.toLowerCase().trim() } });
  if (!user) return NextResponse.json({ error: 'Account not found' }, { status: 404 });

  const result = await verifyOtp(user.id, 'REGISTER_VERIFY', code);
  if (!result.ok) {
    const messages: Record<string, string> = {
      NO_CODE: 'No verification code was requested for this account.',
      EXPIRED: 'This code has expired. Request a new one.',
      MISMATCH: 'That code is incorrect.'
    };
    return NextResponse.json({ error: messages[result.reason] }, { status: 400 });
  }

  await prisma.user.update({ where: { id: user.id }, data: { emailVerified: new Date() } });

  return NextResponse.json({ ok: true });
}
