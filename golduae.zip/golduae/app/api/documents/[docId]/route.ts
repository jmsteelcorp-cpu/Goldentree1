import { NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireSession } from '@/lib/authz';

const schema = z.object({ fileUrl: z.string().url() });

export async function PATCH(req: Request, { params }: { params: { docId: string } }) {
  const { session, error } = await requireSession();
  if (error) return error;

  const doc = await prisma.document.findUnique({
    where: { id: params.docId },
    include: { application: { include: { agent: true } } }
  });
  if (!doc) return NextResponse.json({ error: 'Document slot not found' }, { status: 404 });

  const role = (session!.user as any).role;
  const userId = (session!.user as any).id;
  const agentId = (session!.user as any).agentId;

  const allowed =
    (role === 'USER' && doc.application.userId === userId) ||
    (role === 'AGENT' && doc.application.agentId === agentId);
  if (!allowed) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Invalid input' }, { status: 400 });

  const updated = await prisma.document.update({
    where: { id: doc.id },
    data: { fileUrl: parsed.data.fileUrl, status: 'PENDING_UPLOAD', rejectionComment: null }
  });

  return NextResponse.json({ document: updated });
}
