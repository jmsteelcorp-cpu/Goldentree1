import { NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireSession } from '@/lib/authz';
import { dependentDocChecklist, SPONSOR_DOCS_FOR_DEPENDENTS } from '@/lib/checklist';
import { Relation } from '@prisma/client';

const schema = z.object({
  relation: z.nativeEnum(Relation),
  fullName: z.string().optional()
});

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const { session, error } = await requireSession();
  if (error) return error;

  const application = await prisma.application.findUnique({
    where: { id: params.id },
    include: { dependents: true, documents: true }
  });
  if (!application || application.userId !== (session!.user as any).id) {
    return NextResponse.json({ error: 'Application not found' }, { status: 404 });
  }

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Invalid input' }, { status: 400 });

  const dependent = await prisma.dependent.create({
    data: { applicationId: application.id, relation: parsed.data.relation, fullName: parsed.data.fullName }
  });

  await prisma.document.createMany({
    data: dependentDocChecklist(parsed.data.relation).map((type) => ({
      applicationId: application.id,
      dependentId: dependent.id,
      type
    }))
  });

  // Sponsor documents are only needed once, the first time a dependent is added.
  const alreadyHasSponsorDocs = application.documents.some((d) =>
    SPONSOR_DOCS_FOR_DEPENDENTS.includes(d.type) && !d.dependentId
  );
  if (!alreadyHasSponsorDocs && application.dependents.length === 0) {
    await prisma.document.createMany({
      data: SPONSOR_DOCS_FOR_DEPENDENTS.map((type) => ({ applicationId: application.id, type }))
    });
  }

  const updated = await prisma.application.findUnique({
    where: { id: application.id },
    include: { dependents: { include: { documents: true } }, documents: true }
  });

  return NextResponse.json({ application: updated });
}
