import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireSession } from '@/lib/authz';

export async function POST(_req: Request, { params }: { params: { id: string } }) {
  const { session, error } = await requireSession();
  if (error) return error;

  const application = await prisma.application.findUnique({
    where: { id: params.id },
    include: { documents: true }
  });
  if (!application) return NextResponse.json({ error: 'Not found' }, { status: 404 });

  const role = (session!.user as any).role;
  const allowed =
    (role === 'USER' && application.userId === (session!.user as any).id) ||
    (role === 'AGENT' && application.agentId === (session!.user as any).agentId);
  if (!allowed) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

  const missing = application.documents.filter((d) => !d.fileUrl);
  if (missing.length > 0) {
    return NextResponse.json(
      { error: `${missing.length} document(s) still need to be uploaded before you can submit.` },
      { status: 400 }
    );
  }

  await prisma.document.updateMany({
    where: { applicationId: application.id },
    data: { status: 'UNDER_VERIFICATION' }
  });

  const updated = await prisma.application.update({
    where: { id: application.id },
    data: { status: 'DOCS_UNDER_VERIFICATION' },
    include: { documents: true }
  });

  return NextResponse.json({ application: updated });
}
