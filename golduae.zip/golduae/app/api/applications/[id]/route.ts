import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireSession } from '@/lib/authz';

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const { session, error } = await requireSession();
  if (error) return error;

  const application = await prisma.application.findUnique({
    where: { id: params.id },
    include: {
      property: true,
      dependents: { include: { documents: true } },
      documents: true,
      payment: true,
      user: { select: { id: true, name: true, email: true, contactNo: true } },
      agent: { select: { agentCode: true, user: { select: { name: true } } } }
    }
  });

  if (!application) return NextResponse.json({ error: 'Not found' }, { status: 404 });

  const role = (session!.user as any).role;
  const userId = (session!.user as any).id;
  const agentId = (session!.user as any).agentId;

  const allowed =
    role === 'ADMIN' ||
    (role === 'USER' && application.userId === userId) ||
    (role === 'AGENT' && application.agentId === agentId);

  if (!allowed) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

  return NextResponse.json({ application });
}
