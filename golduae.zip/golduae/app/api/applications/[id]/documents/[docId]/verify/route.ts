import { NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireRole } from '@/lib/authz';

const schema = z.object({
  decision: z.enum(['APPROVED', 'REJECTED']),
  comment: z.string().optional()
});

export async function PATCH(req: Request, { params }: { params: { id: string; docId: string } }) {
  const { session, error } = await requireRole('ADMIN');
  if (error) return error;

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Invalid input' }, { status: 400 });

  const doc = await prisma.document.update({
    where: { id: params.docId },
    data: {
      status: parsed.data.decision,
      rejectionComment: parsed.data.decision === 'REJECTED' ? parsed.data.comment ?? 'Please re-upload.' : null,
      verifiedByAdminId: (session!.user as any).id,
      verifiedAt: new Date()
    }
  });

  const allDocs = await prisma.document.findMany({ where: { applicationId: params.id } });

  let newStatus: 'DOCS_REJECTED' | 'IN_PROGRESS' | undefined;
  if (allDocs.some((d) => d.status === 'REJECTED')) {
    newStatus = 'DOCS_REJECTED';
  } else if (allDocs.every((d) => d.status === 'APPROVED')) {
    newStatus = 'IN_PROGRESS';
  }

  if (newStatus) {
    await prisma.application.update({
      where: { id: params.id },
      data: {
        status: newStatus,
        estimatedCompletionAt:
          newStatus === 'IN_PROGRESS' ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) : undefined
      }
    });
  }

  return NextResponse.json({ document: doc, applicationStatus: newStatus });
}
