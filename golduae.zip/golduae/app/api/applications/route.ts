import { NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { requireSession } from '@/lib/authz';
import { generateTaskNo } from '@/lib/pricing';
import { INVESTOR_VISA_CHECKLIST, propertyConditionalDocs } from '@/lib/checklist';

const schema = z.object({
  type: z.enum(['INVESTOR_VISA', 'DEPENDENT_VISA', 'PROPERTY_VALUATION']),
  propertyId: z.string().optional(),
  agentCode: z.string().optional()
});

export async function POST(req: Request) {
  const { session, error } = await requireSession();
  if (error) return error;

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Invalid input' }, { status: 400 });

  const userId = (session!.user as any).id;
  const { type, propertyId, agentCode } = parsed.data;

  let agentId: string | undefined;
  if (agentCode) {
    const agent = await prisma.agent.findUnique({ where: { agentCode: agentCode.toUpperCase() } });
    if (agent) agentId = agent.id;
  } else {
    const user = await prisma.user.findUnique({ where: { id: userId } });
    agentId = user?.referredByAgentId ?? undefined;
  }

  let property = null;
  if (propertyId) {
    property = await prisma.property.findUnique({ where: { id: propertyId } });
    if (!property || property.userId !== userId) {
      return NextResponse.json({ error: 'Property not found' }, { status: 404 });
    }
    if (type === 'INVESTOR_VISA' && property.eligibility !== 'ELIGIBLE') {
      return NextResponse.json({ error: 'This property has not been confirmed eligible yet.' }, { status: 400 });
    }
  }

  const prefix = type === 'INVESTOR_VISA' ? 'INV' : type === 'DEPENDENT_VISA' ? 'DEP' : 'VAL';
  const taskNo = generateTaskNo(prefix);

  const application = await prisma.application.create({
    data: {
      taskNo,
      type,
      userId,
      agentId,
      propertyId: property?.id,
      status: 'DRAFT'
    }
  });

  // Seed the base checklist for an investor-visa application. Dependent-specific
  // docs are added later via /api/applications/[id]/dependents.
  if (type === 'INVESTOR_VISA') {
    const docs = [
      ...INVESTOR_VISA_CHECKLIST,
      ...(property ? propertyConditionalDocs({ hasMortgage: property.hasMortgage, isOffPlan: property.isOffPlan }) : [])
    ];
    await prisma.document.createMany({
      data: docs.map((type) => ({ applicationId: application.id, type }))
    });
  }

  if (type === 'PROPERTY_VALUATION') {
    await prisma.document.createMany({
      data: [{ type: 'TITLE_DEED' }, { type: 'PASSPORT' }, { type: 'EMIRATES_ID' }].map((d) => ({
        applicationId: application.id,
        type: d.type as any
      }))
    });
  }

  return NextResponse.json({ application });
}

export async function GET() {
  const { session, error } = await requireSession();
  if (error) return error;

  const role = (session!.user as any).role;
  const userId = (session!.user as any).id;
  const agentId = (session!.user as any).agentId;

  const where =
    role === 'ADMIN'
      ? {}
      : role === 'AGENT'
      ? { agentId }
      : { userId };

  const applications = await prisma.application.findMany({
    where,
    include: { property: true, dependents: true, documents: true, payment: true, user: { select: { name: true, email: true } } },
    orderBy: { createdAt: 'desc' }
  });

  return NextResponse.json({ applications });
}
