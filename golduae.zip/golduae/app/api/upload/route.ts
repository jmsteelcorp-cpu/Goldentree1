import { NextResponse } from 'next/server';
import { put } from '@vercel/blob';
import { requireSession } from '@/lib/authz';

export const runtime = 'nodejs';

const MAX_BYTES = 12 * 1024 * 1024; // 12MB
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];

export async function POST(req: Request) {
  const { session, error } = await requireSession();
  if (error) return error;

  const formData = await req.formData();
  const file = formData.get('file');
  const folder = (formData.get('folder') as string) || 'misc';

  if (!(file instanceof File)) {
    return NextResponse.json({ error: 'No file provided' }, { status: 400 });
  }
  if (!ALLOWED_TYPES.includes(file.type)) {
    return NextResponse.json({ error: 'Only JPG, PNG, WEBP or PDF files are accepted.' }, { status: 400 });
  }
  if (file.size > MAX_BYTES) {
    return NextResponse.json({ error: 'File exceeds the 12MB limit.' }, { status: 400 });
  }

  const userId = (session!.user as any).id;
  const safeName = file.name.replace(/[^a-zA-Z0-9.\-_]/g, '_');
  const key = `${folder}/${userId}/${Date.now()}-${safeName}`;

  const blob = await put(key, file, { access: 'public' });

  return NextResponse.json({ url: blob.url, contentType: file.type });
}
