import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireRole } from '@/lib/authz';

export async function GET() {
  const { session, error } = await requireRole('AGENT');
  if (error) return error;

  const agentId = (session!.user as any).agentId;
  const commissions = await prisma.commission.findMany({
    where: { agentId },
    include: { agent: false },
    orderBy: { createdAt: 'desc' }
  });

  const totalEarned = commissions.reduce((sum, c) => sum + c.amountAed, 0);
  const totalPending = commissions.filter((c) => c.payoutStatus === 'PENDING').reduce((sum, c) => sum + c.amountAed, 0);

  return NextResponse.json({ commissions, totalEarned, totalPending });
}
