import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { issueOtp } from '@/lib/otp';

const schema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  contactNo: z.string().min(6),
  password: z.string().min(8),
  emiratesIdNo: z.string().min(4),
  bankName: z.string().optional(),
  bankIban: z.string().optional()
});

function generateAgentCode(name: string) {
  const prefix = name.replace(/[^A-Za-z]/g, '').slice(0, 3).toUpperCase() || 'AGT';
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `${prefix}${rand}`;
}

export async function POST(req: Request) {
  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const { name, email, contactNo, password, emiratesIdNo, bankName, bankIban } = parsed.data;

  const existing = await prisma.user.findUnique({ where: { email: email.toLowerCase().trim() } });
  if (existing) return NextResponse.json({ error: 'An account with this email already exists.' }, { status: 409 });

  const passwordHash = await bcrypt.hash(password, 12);

  let agentCode = generateAgentCode(name);
  // ensure uniqueness
  while (await prisma.agent.findUnique({ where: { agentCode } })) {
    agentCode = generateAgentCode(name);
  }

  const user = await prisma.user.create({
    data: {
      name,
      email: email.toLowerCase().trim(),
      contactNo,
      passwordHash,
      role: 'AGENT',
      agentProfile: {
        create: { agentCode, emiratesIdNo, bankName, bankIban }
      }
    },
    include: { agentProfile: true }
  });

  await issueOtp(user.id, 'REGISTER_VERIFY', user.email);

  return NextResponse.json({ ok: true, agentCode: user.agentProfile?.agentCode });
}
