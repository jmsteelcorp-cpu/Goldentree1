import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { NextResponse } from 'next/server';

export async function requireSession() {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return { session: null, error: NextResponse.json({ error: 'Not authenticated' }, { status: 401 }) };
  }
  return { session, error: null };
}

export async function requireRole(role: 'USER' | 'AGENT' | 'ADMIN') {
  const { session, error } = await requireSession();
  if (error) return { session: null, error };
  if ((session!.user as any).role !== role) {
    return { session: null, error: NextResponse.json({ error: 'Forbidden' }, { status: 403 }) };
  }
  return { session, error: null };
}
