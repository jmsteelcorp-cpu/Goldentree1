import { DocumentType, Relation } from '@prisma/client';

export const INVESTOR_VISA_CHECKLIST: DocumentType[] = [
  DocumentType.PASSPORT,
  DocumentType.VISA_COPY
];

/** Property-side documents, added conditionally based on the deed OCR result. */
export function propertyConditionalDocs(opts: { hasMortgage: boolean | null; isOffPlan: boolean | null }) {
  const docs: DocumentType[] = [];
  if (opts.hasMortgage) docs.push(DocumentType.BANK_NOC); // NOC from bank
  if (opts.isOffPlan) docs.push(DocumentType.DEVELOPER_SOA_NOC); // SOA/NOC from developer
  return docs;
}

/** Sponsor-side docs required once any dependent is added. */
export const SPONSOR_DOCS_FOR_DEPENDENTS: DocumentType[] = [
  DocumentType.EMIRATES_ID, // "Emirates id of sponsor"
  DocumentType.VISA_COPY, // sponsor visa copy
  DocumentType.PASSPORT // sponsor passport
];

/** Relationship-proof document required for a given dependent relation. */
export function relationshipDocFor(relation: Relation): DocumentType {
  switch (relation) {
    case Relation.WIFE:
      return DocumentType.MARRIAGE_CERTIFICATE;
    case Relation.SON:
    case Relation.DAUGHTER:
      return DocumentType.BIRTH_CERTIFICATE;
    case Relation.PARENT:
      return DocumentType.SPONSOR_BIRTH_CERTIFICATE;
    case Relation.SERVANT:
      return DocumentType.OFFER_LETTER;
    case Relation.SISTER:
    case Relation.SIBLING:
      return DocumentType.BIRTH_CERTIFICATE;
    default:
      return DocumentType.OTHER;
  }
}

/** Standard per-dependent docs: passport + visa copy, plus the relation-specific proof. */
export function dependentDocChecklist(relation: Relation): DocumentType[] {
  return [DocumentType.PASSPORT, DocumentType.VISA_COPY, relationshipDocFor(relation)];
}

export const DOCUMENT_TYPE_LABELS: Record<DocumentType, string> = {
  PASSPORT: 'Passport (front / back / cover page)',
  VISA_COPY: 'Visa copy',
  EMIRATES_ID: 'Emirates ID',
  MARRIAGE_CERTIFICATE: 'Marriage certificate (attested)',
  BIRTH_CERTIFICATE: 'Birth certificate (attested)',
  SPONSOR_BIRTH_CERTIFICATE: "Sponsor's birth certificate",
  OFFER_LETTER: 'Offer letter from sponsor',
  TITLE_DEED: 'Title deed',
  BANK_NOC: 'NOC from bank (mortgaged property)',
  DEVELOPER_SOA_NOC: 'SOA / NOC from developer (off-plan)',
  OTHER: 'Other document'
};

export const RELATION_LABELS: Record<Relation, string> = {
  PARENT: 'Parent',
  WIFE: 'Wife',
  SISTER: 'Sister',
  DAUGHTER: 'Daughter',
  SON: 'Son',
  SIBLING: 'Sibling',
  SERVANT: 'Servant'
};
