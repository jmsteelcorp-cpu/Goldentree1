import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';

export interface InvoiceLine {
  label: string;
  amountAed: number;
}

export async function generateInvoicePdf(opts: {
  invoiceNo: string;
  billingName: string;
  agentCode?: string | null;
  lines: InvoiceLine[];
  total: number;
  paid: boolean;
}): Promise<Uint8Array> {
  const doc = await PDFDocument.create();
  const page = doc.addPage([595, 842]); // A4
  const font = await doc.embedFont(StandardFonts.Helvetica);
  const bold = await doc.embedFont(StandardFonts.HelveticaBold);

  const gold = rgb(0.72, 0.53, 0.14);
  const dark = rgb(0.1, 0.1, 0.12);

  let y = 780;

  page.drawText('GoldUAE', { x: 50, y, size: 26, font: bold, color: gold });
  page.drawText(opts.paid ? 'RECEIPT' : 'INVOICE', { x: 450, y, size: 16, font: bold, color: dark });
  y -= 30;
  page.drawText('Golden Visa & Property Valuation Services', { x: 50, y, size: 10, font, color: dark });
  y -= 50;

  page.drawText(`Invoice No: ${opts.invoiceNo}`, { x: 50, y, size: 11, font, color: dark });
  y -= 16;
  page.drawText(`Billing Name: ${opts.billingName}`, { x: 50, y, size: 11, font, color: dark });
  y -= 16;
  if (opts.agentCode) {
    page.drawText(`Agent Code: ${opts.agentCode}`, { x: 50, y, size: 11, font, color: dark });
    y -= 16;
  }
  page.drawText(`Date: ${new Date().toLocaleDateString('en-GB')}`, { x: 50, y, size: 11, font, color: dark });
  y -= 40;

  page.drawLine({ start: { x: 50, y }, end: { x: 545, y }, thickness: 1, color: gold });
  y -= 24;
  page.drawText('Description', { x: 50, y, size: 11, font: bold, color: dark });
  page.drawText('Amount (AED)', { x: 450, y, size: 11, font: bold, color: dark });
  y -= 16;

  for (const line of opts.lines) {
    page.drawText(line.label, { x: 50, y, size: 11, font, color: dark });
    page.drawText(line.amountAed.toLocaleString('en-AE'), { x: 450, y, size: 11, font, color: dark });
    y -= 20;
  }

  y -= 10;
  page.drawLine({ start: { x: 50, y }, end: { x: 545, y }, thickness: 1, color: gold });
  y -= 24;
  page.drawText('Total', { x: 50, y, size: 13, font: bold, color: dark });
  page.drawText(`AED ${opts.total.toLocaleString('en-AE')}`, { x: 420, y, size: 13, font: bold, color: gold });

  return doc.save();
}
