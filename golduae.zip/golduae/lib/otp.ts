import { prisma } from '@/lib/prisma';
import { Resend } from 'resend';
import { OtpPurpose } from '@prisma/client';

const resend = process.env.RESEND_API_KEY ? new Resend(process.env.RESEND_API_KEY) : null;

function generateCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

export async function issueOtp(userId: string, purpose: OtpPurpose, deliverTo: string) {
  const code = generateCode();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

  await prisma.otpCode.create({
    data: { userId, purpose, code, expiresAt }
  });

  if (resend) {
    await resend.emails.send({
      from: process.env.EMAIL_FROM || 'GoldUAE <no-reply@golduae.xyz>',
      to: deliverTo,
      subject: 'Your GoldUAE verification code',
      html: `<p>Your verification code is <strong>${code}</strong>. It expires in 10 minutes.</p>`
    });
  } else {
    // No email provider configured — log so the flow is testable in dev/preview.
    console.log(`[OTP] ${purpose} code for ${deliverTo}: ${code}`);
  }

  return { expiresAt };
}

export async function verifyOtp(userId: string, purpose: OtpPurpose, code: string) {
  const record = await prisma.otpCode.findFirst({
    where: { userId, purpose, consumedAt: null },
    orderBy: { createdAt: 'desc' }
  });

  if (!record) return { ok: false, reason: 'NO_CODE' as const };
  if (record.expiresAt < new Date()) return { ok: false, reason: 'EXPIRED' as const };
  if (record.code !== code) return { ok: false, reason: 'MISMATCH' as const };

  await prisma.otpCode.update({
    where: { id: record.id },
    data: { consumedAt: new Date() }
  });

  return { ok: true as const };
}
