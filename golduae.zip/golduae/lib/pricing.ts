export const INVESTOR_VISA_PACKAGE_AED = 130_000;
export const DEPENDENT_VISA_PACKAGE_AED = 7_000;

export function calculateInvoiceTotal(dependentCount: number) {
  const investor = INVESTOR_VISA_PACKAGE_AED;
  const dependents = dependentCount * DEPENDENT_VISA_PACKAGE_AED;
  return {
    investor,
    dependents,
    total: investor + dependents
  };
}

export function generateTaskNo(prefix: 'INV' | 'DEP' | 'VAL') {
  const rand = Math.random().toString(36).slice(2, 7).toUpperCase();
  const stamp = Date.now().toString(36).toUpperCase();
  return `${prefix}-${stamp}-${rand}`;
}

const AGENT_COMMISSION_RATE = 0.1; // 10% of package value — adjust as needed

export function calculateCommission(amountAed: number) {
  return Math.round(amountAed * AGENT_COMMISSION_RATE);
}
