/**
 * Title-deed OCR.
 *
 * Uses Google Cloud Vision's DOCUMENT_TEXT_DETECTION REST endpoint (an API key
 * is enough — no service-account JSON needed) to pull raw text off an
 * uploaded title deed / valuation image or PDF page, then runs a set of
 * regex heuristics tuned to Dubai Land Department (DLD) title deed layouts
 * to extract the structured fields the eligibility check needs.
 *
 * Real deeds vary in layout, so this is best-effort: every parsed field is
 * optional, `ocrConfidence` reflects how many of the target fields were
 * actually found, and the raw text is always stored so an admin can review
 * or correct it manually.
 */

const GOOGLE_VISION_API_KEY = process.env.GOOGLE_VISION_API_KEY;
const VISION_ENDPOINT = 'https://vision.googleapis.com/v1/images:annotate';

export interface ParsedDeed {
  rawText: string;
  confidence: number;
  value: number | null;
  ownerName: string | null;
  propertyType: string | null;
  developerName: string | null;
  projectName: string | null;
  purchaseDate: string | null; // ISO date
  hasMortgage: boolean | null;
  isOffPlan: boolean | null;
  paymentPlanWithDeveloper: boolean | null;
}

/**
 * fileBase64: raw base64 (no data: prefix) of a JPG/PNG/PDF page.
 */
export async function runDeedOcr(fileBase64: string): Promise<ParsedDeed> {
  if (!GOOGLE_VISION_API_KEY) {
    throw new Error(
      'GOOGLE_VISION_API_KEY is not configured. Set it in your environment to enable title-deed OCR.'
    );
  }

  const res = await fetch(`${VISION_ENDPOINT}?key=${GOOGLE_VISION_API_KEY}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      requests: [
        {
          image: { content: fileBase64 },
          features: [{ type: 'DOCUMENT_TEXT_DETECTION' }]
        }
      ]
    })
  });

  if (!res.ok) {
    const errBody = await res.text();
    throw new Error(`Vision API request failed (${res.status}): ${errBody}`);
  }

  const json = await res.json();
  const annotation = json.responses?.[0];
  if (annotation?.error) {
    throw new Error(`Vision API error: ${annotation.error.message}`);
  }

  const rawText: string = annotation?.fullTextAnnotation?.text ?? '';
  return parseDeedText(rawText);
}

export function parseDeedText(rawText: string): ParsedDeed {
  const text = rawText.replace(/\r/g, '');
  const flat = text.replace(/\s+/g, ' ');

  let fieldsFound = 0;
  const total = 8;

  // Property value — look for AED amounts near "value" / "consideration" / "amount"
  let value: number | null = null;
  const valueMatch =
    flat.match(/(?:value|consideration|purchase\s*price|amount)\D{0,15}(?:AED)?\s*([\d,]{4,})/i) ||
    flat.match(/AED\s*([\d,]{4,})/i);
  if (valueMatch) {
    const n = parseFloat(valueMatch[1].replace(/,/g, ''));
    if (!Number.isNaN(n)) {
      value = n;
      fieldsFound++;
    }
  }

  // Owner name
  let ownerName: string | null = null;
  const ownerMatch = flat.match(/owner(?:'s)?\s*name\s*[:\-]?\s*([A-Za-z .'-]{3,60})/i);
  if (ownerMatch) {
    ownerName = ownerMatch[1].trim();
    fieldsFound++;
  }

  // Property type
  let propertyType: string | null = null;
  const typeMatch = flat.match(/property\s*type\s*[:\-]?\s*(villa|apartment|townhouse|plot|land|office|shop|warehouse)/i);
  if (typeMatch) {
    propertyType = capitalize(typeMatch[1]);
    fieldsFound++;
  }

  // Developer name
  let developerName: string | null = null;
  const devMatch = flat.match(/developer(?:'s)?\s*name\s*[:\-]?\s*([A-Za-z0-9 .&'-]{3,60})/i);
  if (devMatch) {
    developerName = devMatch[1].trim();
    fieldsFound++;
  }

  // Project name
  let projectName: string | null = null;
  const projMatch = flat.match(/project\s*name\s*[:\-]?\s*([A-Za-z0-9 .&'-]{3,60})/i);
  if (projMatch) {
    projectName = projMatch[1].trim();
    fieldsFound++;
  }

  // Purchase / registration date
  let purchaseDate: string | null = null;
  const dateMatch = flat.match(
    /(?:date\s*of\s*purchase|registration\s*date|transaction\s*date)\s*[:\-]?\s*(\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4})/i
  );
  if (dateMatch) {
    const iso = toIsoDate(dateMatch[1]);
    if (iso) {
      purchaseDate = iso;
      fieldsFound++;
    }
  }

  // Mortgage
  let hasMortgage: boolean | null = null;
  if (/mortgage\s*[:\-]?\s*(yes|registered|active)/i.test(flat)) {
    hasMortgage = true;
    fieldsFound++;
  } else if (/mortgage\s*[:\-]?\s*(no|none|n\/a)/i.test(flat)) {
    hasMortgage = false;
    fieldsFound++;
  }

  // Off-plan vs ready
  let isOffPlan: boolean | null = null;
  if (/off[\s-]?plan/i.test(flat)) {
    isOffPlan = true;
    fieldsFound++;
  } else if (/\bready\b/i.test(flat)) {
    isOffPlan = false;
    fieldsFound++;
  }

  // Payment plan with developer (only meaningful if off-plan)
  const paymentPlanWithDeveloper = /payment\s*plan/i.test(flat) ? true : null;

  return {
    rawText: text,
    confidence: Math.round((fieldsFound / total) * 100) / 100,
    value,
    ownerName,
    propertyType,
    developerName,
    projectName,
    purchaseDate,
    hasMortgage,
    isOffPlan,
    paymentPlanWithDeveloper
  };
}

function capitalize(s: string) {
  return s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();
}

function toIsoDate(raw: string): string | null {
  const parts = raw.split(/[\/\-.]/).map((p) => p.trim());
  if (parts.length !== 3) return null;
  let [a, b, c] = parts.map((p) => parseInt(p, 10));
  if (c < 100) c += 2000;
  // Assume DD/MM/YYYY (common in UAE documents)
  const date = new Date(Date.UTC(c, b - 1, a));
  if (Number.isNaN(date.getTime())) return null;
  return date.toISOString();
}

export const GOLDEN_VISA_MIN_PROPERTY_VALUE_AED = 2_000_000;
